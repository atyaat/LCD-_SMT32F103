/**
  ******************************************************************************
  * @file    main.c
  * @author  fire
  * @version V1.0
  * @date    2013-xx-xx
  * @brief   ����5.0��lcd��ʾӢ���ַ�
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ�� iSO STM32 ������ 

* ��̳    :http://www.firebbs.cn
  * �Ա�    :http://fire-stm32.taobao.com
  *
  ******************************************************************************
  */ 
 
#include "stm32f10x.h"
#include "bsp_ra8875_lcd.h"
#include "bsp_usart1.h"
#include "bsp_can.h"
#include "math.h"
__IO uint32_t flag = 0;		 //���ڱ�־�Ƿ���յ����ݣ����жϺ����и�ֵ
__IO uint32_t flagx =0 ;		 //���ڱ�־�������ݵ����ͣ����жϺ����и�ֵ
CanTxMsg TxMessage;			     //���ͻ�����
CanRxMsg RxMessage;				 //���ջ�����
                                 //ȫ�ֱ���Ҫ���������ٶ���һ��
								
void Delay(__IO u32 nCount); 
void RA8875_Test(void);

/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
int main(void)
{  
  /*��ʼ��Һ����*/
  LCD_Init();	
  
  /*�����ȳ�ʼ��FSMC(Һ��)���ٳ�ʼ������*/
  USART1_Config();  
  CAN_Config();
	
	int32_t x = 260;   //260
	
	printf("\r\n ��ӭʹ��Ұ�� F103-�Ե� STM32 �����塣\r\n");
    printf("\r\n Ұ��F103-�Ե� CANͨѶ�ػ�ʵ������\r\n");	
	printf("\r\n ʵ�鲽�裺\r\n");
	printf("\r\n 1.ʹ�ûػ�ģʽ������Ҫ�����ⲿоƬ\r\n");
	printf("\r\n 2.���¿������KEY1������ʹ��CAN���ⷢ��0-7�����ݰ���������չIDΪ0x1314 (���ڻػ�ģʽ�����Լ����͸��Լ�)\r\n");
	printf("\r\n 3.���������CAN���յ���չIDΪ0x1314�����ݰ�����������Դ�ӡ�����ڡ� \r\n");
	printf("\r\n 4.�����е�can������Ϊ1MBps��Ϊstm32��can������ʡ� \r\n");
	
  RA8875_ClrScr(CL_BLACK);	/* ��������ʾȫ�� */
	
	RA8875_SetFrontColor(CL_WHITE);
    RA8875_SetFont( RA_FONT_32,  0, 0);
    RA8875_SetTextZoom(1,2);  
	                                           
	RA8875_Makecurve(400,240,210,210,CL_GREEN);      //��������
    RA8875_Makecurv(400,240,210,210,CL_GREEN);       // �Ұ��
//           ת�ٱ���ʾ
	
	RA8875_DrawCircle(400,240,200,CL_WHITE);              // ��Ȧ
	RA8875_DrawCircle(400,240,201,CL_WHITE);
	RA8875_DrawCircle(400,240,202,CL_WHITE);
	RA8875_DrawCircle(400,240,203,CL_WHITE);
	RA8875_DrawCircle(400,240,204,CL_WHITE);
	RA8875_DrawCircle(400,240,205,CL_GREEN);
	RA8875_DrawCircle(400,240,206,CL_GREEN);
	RA8875_DrawCircle(400,240,207,CL_GREEN);
	RA8875_DrawCircle(400,240,208,CL_BLUE);
	RA8875_DrawCircle(400,240,209,CL_BLUE);
	RA8875_DrawCircle(400,240,209,CL_BLUE);
	
	RA8875_Drawtriangle(253,381,259,387,270,370,CL_WHITE);    //�� �̶�  (259,381)   0
	RA8875_Drawtriangle(200,237,200,243,216,240,CL_WHITE);    //         (200,240)   30
	RA8875_Drawtriangle(259,97,250,101,270,110,CL_WHITE);     //         (259,99 )   
	RA8875_Drawtriangle(405,40,395,38,400,55,CL_WHITE);       //         (400,40 )
	 
	RA8875_Drawtriangle(541,97,547,99,530,110,CL_WHITE);      //         (541,99 )
	RA8875_Drawtriangle(600,237,600,243,585,240,CL_WHITE);    //         (600,200)
	RA8875_Drawtriangle(544,379,542,388,530,370,CL_WHITE);    //         (541,381)
		

	                                                          //  ��ص�����ʶ����
	RA8875_DrawLine(700,380,700,80,CL_BLUE); 
	RA8875_DrawLine(701,380,701,80,CL_GREEN); 
	RA8875_DrawLine(702,380,702,80,CL_GREEN); 
	RA8875_DrawLine(703,380,703,80,CL_WHITE); 
	
	
	RA8875_Drawtriangle(703,351-(30*0),703,349-(30*0),710,350-(30*0),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*1),703,349-(30*1),710,350-(30*1),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*2),703,349-(30*2),710,350-(30*2),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*3),703,349-(30*3),710,350-(30*3),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*4),703,349-(30*4),710,350-(30*4),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*5),703,349-(30*5),710,350-(30*5),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*6),703,349-(30*6),710,350-(30*6),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*7),703,349-(30*7),710,350-(30*7),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*8),703,349-(30*8),710,350-(30*8),CL_WHITE);
	RA8875_Drawtriangle(703,351-(30*9),703,349-(30*9),710,350-(30*9),CL_WHITE);

//	RA8875_DrawRect(0,350,30,100,CL_RED);               //����¶Ⱥ͵���¶�
//	RA8875_DrawRect(0,350-(30*1),30,100,CL_RED);
//	RA8875_DrawRect(0,350-(30*2),30,100,CL_YELLOW);
//	RA8875_DrawRect(0,350-(30*3),30,100,CL_YELLOW);
//	RA8875_DrawRect(0,350-(30*4),30,100,CL_YELLOW);
//	RA8875_DrawRect(0,350-(30*5),30,100,CL_GREEN);
//	RA8875_DrawRect(0,350-(30*6),30,100,CL_GREEN);
//	RA8875_DrawRect(0,350-(30*7),30,100,CL_GREEN);
//	RA8875_DrawRect(0,350-(30*8),30,100,CL_GREEN);
//	RA8875_DrawRect(0,350-(30*9),30,100,CL_GREEN);

	RA8875_DrawLine(100,380,100,80,CL_WHITE); 
	RA8875_DrawLine(101,380,101,80,CL_GREEN); 
	RA8875_DrawLine(102,380,102,80,CL_GREEN); 
	RA8875_DrawLine(103,380,103,80,CL_BLUE); 
	
	
	RA8875_Drawtriangle(100,351-(30*0),100,349-(30*0),93,350-(30*0),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*1),100,349-(30*1),93,350-(30*1),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*2),100,349-(30*2),93,350-(30*2),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*3),100,349-(30*3),93,350-(30*3),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*4),100,349-(30*4),93,350-(30*4),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*5),100,349-(30*5),93,350-(30*5),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*6),100,349-(30*6),93,350-(30*6),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*7),100,349-(30*7),93,350-(30*7),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*8),100,349-(30*8),93,350-(30*8),CL_WHITE);
	RA8875_Drawtriangle(100,351-(30*9),100,349-(30*9),93,350-(30*9),CL_WHITE);
	
    RA8875_FillCircle(200,480,50,CL_GREEN);     //���Բ
	RA8875_FillCircle(600,480,50,CL_GREEN);
	RA8875_FillCircle(400,240,16,CL_RED);
	
	RA8875_Drawtriangle(400,250,400,230,x,381,CL_RED);  //ָ��      x=259 y=381;
	
	RA8875_DrawCircle(200,480,51,CL_RED);       //��Բ
	RA8875_DrawCircle(200,480,52,CL_RED);
	RA8875_DrawCircle(200,480,53,CL_RED);
	RA8875_DrawCircle(600,480,51,CL_RED);
	RA8875_DrawCircle(600,480,52,CL_RED);
	RA8875_DrawCircle(600,480,53,CL_RED);
	
	RA8875_SetTextZoom(0,0);

    RA8875_DispStr(80,448,":���");
    RA8875_DispStr(660,448,"���:");
	RA8875_DispStr(432,370,"Km/h");
	
	RA8875_SetTextZoom(0,0);
	RA8875_SetFrontColor(CL_GREEN);
	
	RA8875_DispStr(638,380,"soc:");  
	RA8875_DispStr(768,380,"%");
	RA8875_DispStr(100,380,"oC");
	
	RA8875_DispStr(0,0,"�Ž�ѧԺ");
	RA8875_DispStr(672,0,"���ٳ���");
	
	
	RA8875_SetFont( RA_FONT_16,  0, 0);
	RA8875_SetFrontColor(CL_RED);
	RA8875_DispStr(680,342,"10");                //������ʶ
	RA8875_DispStr(680,342-(30*1),"20");
	RA8875_DispStr(680,342-(30*2),"30");
	RA8875_SetFrontColor(CL_YELLOW);
	RA8875_DispStr(680,342-(30*3),"40");
	RA8875_DispStr(680,342-(30*4),"50");
	RA8875_SetFrontColor(CL_GREEN);
	RA8875_DispStr(680,342-(30*5),"60");
	RA8875_DispStr(680,342-(30*6),"70");
	RA8875_DispStr(680,342-(30*7),"80");
	RA8875_DispStr(680,342-(30*8),"90");
	RA8875_DispStr(672,342-(30*9),"100");
	
	                              RA8875_SetFrontColor(CL_GREEN);                //�¶ȱ�ʶ 
	RA8875_DispStr(105,342,"10");                
	RA8875_DispStr(105,342-(30*1),"20");
	RA8875_DispStr(105,342-(30*2),"30");                              
	RA8875_DispStr(105,342-(30*3),"40");
	RA8875_SetFrontColor(CL_YELLOW);
	RA8875_DispStr(105,342-(30*4),"50");
	                             
	RA8875_DispStr(105,342-(30*5),"60");
	RA8875_DispStr(105,342-(30*6),"70");
	                              RA8875_SetFrontColor(CL_RED); 
	RA8875_DispStr(105,342-(30*7),"80");
	RA8875_DispStr(105,342-(30*8),"90");
	RA8875_DispStr(105,342-(30*9),"100");
	
	                              RA8875_SetFrontColor(CL_GREEN);                //�ٶȱ�ʶ
	RA8875_DispStr(230,385,"00");                
	RA8875_DispStr(170,230,"30");                             
	RA8875_DispStr(230,80,"60");
	RA8875_SetFrontColor(CL_YELLOW);
	RA8875_DispStr(390,18,"90");
	RA8875_DispStr(555,80,"120");
	RA8875_SetFrontColor(CL_RED); 
	RA8875_DispStr(610,232,"150");
	RA8875_DispStr(550,390,"180");
	
	RA8875_SetFrontColor(CL_GREEN);
	RA8875_DispStr(0,390,"���:"); 
//	RA8875_DispStr(0,420,"���:"); 
	
	RA8875_SetFont( RA_FONT_32,  0, 0);
	
	
	RA8875_SetTextZoom(1,2);
	RA8875_SetFrontColor(CL_RED);
	
	RA8875_DispStr(360,310,"00");
	
	
	
  
	while( 1 )
  {
		if(flag == 1)
		{		
            printf("\r\n\r\n"); 
			
			if(flagx == 1)
			{
			printf("\r\n ��չID��ExtId��0x%x \r\n",RxMessage.ExtId);
			CAN_DEBUG_ARRAY(RxMessage.Data,8);
		    printf("\r\n\r\n"); 		
				
			}
			if(flagx == 2)
			{
			printf("\r\n ��չID��ExtId��0x%x \r\n",RxMessage.ExtId);
			CAN_DEBUG_ARRAY(RxMessage.Data,8);
					printf("\r\n\r\n"); 
				
			}
				if(flagx == 3)
			{
			printf("\r\n ��չID��ExtId��0x%x \r\n",RxMessage.ExtId);
			CAN_DEBUG_ARRAY(RxMessage.Data,8);
					printf("\r\n\r\n"); 
				
			}
				if(flagx == 4)
			{
			printf("\r\n ��չID��ExtId��0x%x \r\n",RxMessage.ExtId);
			CAN_DEBUG_ARRAY(RxMessage.Data,8);
					printf("\r\n\r\n"); 
				
			}											
			  flag=0;
		}
	    RA8875_Test();
    }
}

void Delay(__IO uint32_t nCount)	 //�򵥵���ʱ����
{
	for(; nCount != 0; nCount--);
}

/*���ڲ��Ը���RA8875�ĺ���*/  //��ʾ����
void RA8875_Test(void)
{

	static uint8_t soc = 0;	                     //����ܵ���
//	static uint8_t battery_status = 0;           //���״̬
	static uint8_t btemp = 0;                    //	����¶�
//	static uint8_t charging_state = 0;           //���״̬
	static uint8_t speed = 0; 	                 //�ٶ�
//	static uint8_t motor_mtatus = 0;              //���״̬
	
    char Soc[100];                       //  ת������������Ӧ���ַ�
//	char Battery_status[100];
	char Btemp[100]; 
//	char Charging_state[100];
	char Speed[100];
//	char Motor_mtatus[100];
	
	
	RA8875_SetFrontColor(CL_RED);
    RA8875_SetFont( RA_FONT_32,  0, 0);
    RA8875_SetTextZoom(0,0);
	
//	RA8875_DispStr(0,0,"Ұ��5.0��Һ��������:");
	
	if(flagx == 1)   //  ��ص�����״̬
{
    uint8_t* a  = RxMessage.Data;
	soc = a[4];             
//	battery_status = a[6];
//1:Sleep (����)    2:Power Up (�Լ�״̬)3:Standby (����״̬)4:Pre-charge (Ԥ��״̬)5:Run (��������״̬)//6:Shutdown (�ػ�״̬)//7:Error (����״̬)"
    if(a[6] == 80)
	{
	  RA8875_SetFrontColor(CL_GREEN);
	  RA8875_DispStr(736,448,"Run");
	}
     if(a[6]  == 48)
	{
		RA8875_SetFrontColor(CL_BLUE);
	  RA8875_DispStr(736,448,"����");
	}
	 if(a[6]  >= 112)
	{
		RA8875_SetFrontColor(CL_RED);
	  RA8875_DispStr(736,448,"Err");
	}
    
		   if(soc >= 10)
	   {
	     sprintf(Soc,"%d",soc);           //������תΪ�ַ�
         RA8875_DispStr(720,380,Soc);	
	   }
	   	   if(soc < 10)
	   {
	     sprintf(Soc,"%d",soc);           //������תΪ�ַ�
		 RA8875_FillRect(720,380,32,16,CL_BLACK);  //��ʮλˢ��
		 RA8875_SetFrontColor(CL_RED);  
         RA8875_DispStr(736,380,Soc);	
	   }
//    sprintf(Soc,"%d",soc);           //������תΪ�ַ�
//    RA8875_DispStr(720,380,Soc);
	
	RA8875_FillRect(710,80,300-soc*3,90,CL_BLACK);   
	   if(soc <=30 )
	   {
	   RA8875_FillRect(710,380-soc*3,soc*3,90	,CL_RED);  //������ʾ����
	   }
	    if(soc >=30 && soc <=50 )
	   {
	   RA8875_FillRect(710,380-soc*3,soc*3,90	,CL_YELLOW);  //������ʾ����
	   }
	    if(soc >= 50 )
	   {
	   RA8875_FillRect(710,380-soc*3,soc*3,90	,CL_BLUE);  //������ʾ����
	   }

       flagx = 0;
}
   if(flagx == 2)           //�¶�
   {
    uint8_t* a  = RxMessage.Data;
	btemp = a[0];
	   
	      RA8875_SetTextZoom(0,0);
	   RA8875_SetFont( RA_FONT_16,  0, 0);
	   
	      if(btemp >= 10)
	   {
	  sprintf(Btemp,"%d",btemp);          //������תΪ�ַ�
	RA8875_DispStr(48,390,Btemp);
	   }
	   	   if(btemp < 10)
	   {
	     sprintf(Btemp,"%d",btemp);           //������תΪ�ַ�
		 RA8875_FillRect(56,390,16,16,CL_BLACK);  //��ʮλˢ��
		 RA8875_SetFrontColor(CL_RED);  
        RA8875_DispStr(48,390,Btemp);	
	   }
	   
//    sprintf(Btemp,"%d",btemp);          //������תΪ�ַ�
//	RA8875_DispStr(48,420,Btemp);
//	   
	RA8875_FillRect(0,80,300-btemp*3,95,CL_BLACK); 
     if(btemp <= 50)
	 {
	 RA8875_FillRect(0,380-btemp*3,btemp*3,95,CL_BLUE4);   
	 }	
     if(btemp >= 50 && btemp <= 80)
	 {
	 RA8875_FillRect(0,380-btemp*3,btemp*3,95,CL_YELLOW);
	 }		 
	 if(btemp >= 80)
	 {
	 RA8875_FillRect(0,380-btemp*3,btemp*3,95,CL_RED);
	 }
	   
	   flagx = 0;
	   
   }	
//    if(flagx == 3)                   //���״̬
//   {
//    uint8_t* a  = RxMessage.Data;
//	charging_state = a[2];
  //"0:ֹͣ���1:������2:�������3:丳���4:������"
//    if(((a[2] >> 4) | 0xFF) == 0x00) 
//	{
//	 RA8875_DispStr(700,448,"ֹͣ���");
//	}
//	 if(((a[2] >> 4)| 0xFF) == 0x01 ) 
//	{
//	 RA8875_DispStr(700,448,"������");
//	}
//	 if(((a[2] >> 4)|0xFF) == 0x04)
//	{
//	 RA8875_DispStr(700,448,"������");
//	}  
//  sprintf(Charging_state,"%d",charging_state); 
//	RA8875_DispStr(100,200,Charging_state);
//	   flagx = 0;   
//   }
     if(flagx == 4)       //���ת�ٺ�״̬
   {
    uint8_t* a  = RxMessage.Data;   
	 uint32_t x,y,x2,y2,x3,y3,x4,y4,x5,y5;
//     speed = ((a[3]*256+a[2])*1.436)/60/3.6;
	  speed = a[0];
	  
//  	motor_mtatus = a[6];
	        RA8875_SetFrontColor(CL_RED);
	   if(a[6] == 6)
	   {
	        RA8875_DispStr(0,448,"Ϩ��"); 
	   }
	   if(a[6] == 5)
	   {
	        RA8875_DispStr(0,448,"����"); 
	   }
	        RA8875_SetTextZoom(1,2);
	    if(speed <10)
		{ 
			RA8875_FillRect(360,310,92,32,CL_BLACK);  //��ʮλˢ��
			RA8875_SetFrontColor(CL_RED); 
			sprintf(Speed,"%d",speed);
		    RA8875_DispStr(393,310,Speed);
		}
		 if(speed >9 && speed < 100)
		{
			RA8875_FillRect(328,310,92,32,CL_BLACK);  //��ʮλˢ��
			RA8875_SetFrontColor(CL_RED);
			sprintf(Speed,"%d",speed);
		    RA8875_DispStr(360,310,Speed);
		}	
		 if(speed > 99)
		{
			sprintf(Speed,"%d",speed);
		    RA8875_DispStr(328,310,Speed);
		}
		 x = 400+185*cos((225-speed*1.5)*3.141596/180);
		 y = 240-185*sin((225-speed*1.5)*3.141596/180);		
		x2 = 400+10*cos((315-speed*1.5)*3.141596/180);
		y2 = 240-10*sin((315-speed*1.5)*3.141596/180);
		x3 = 400+10*cos((135-speed*1.5)*3.141596/180);
		y3 = 240-10*sin((135-speed*1.5)*3.141596/180);
		x4 = 400+185*cos((235-speed*1.5)*3.141596/180);
		y4 = 240-185*sin((235-speed*1.5)*3.141596/180);
		x5 = 400+185*cos((215-speed*1.5)*3.141596/180);
		y5 = 240-185*sin((215-speed*1.5)*3.141596/180);

		RA8875_Drawtriangle(x2,y2,x3,y3,x,y,CL_RED);  //ָ��      x=259 y=381;
		RA8875_Drawtriangle(x2,y2,x4,y4,x,y,CL_BLACK);
        RA8875_Drawtriangle(x3,y3,x5,y5,x,y,CL_BLACK);
		RA8875_FillCircle(400,240,16,CL_RED);
	        flagx = 0;	   
   }

//  RA8875_DispStr(0,0,"Ұ��5.0��Һ��������:");
//  RA8875_DispStr(0,100,"�ֱ��ʣ�800x480 ����");
//  RA8875_DispStr(0,120,"���ݴ�������֧��5�㴥��");
//  RA8875_DispStr(0,180,"��Ļ�Դ������ֿ⣬�Դ���ͼ���棬�ɳ�����������2Dͼ��");
//  RA8875_DispStr(0,300,"Һ������������8080�ӿ�ͨѶ��16λ�����ߣ���ֱ�Ӳ���FSMC����");
//  RA8875_DispStr(0,420,"����������������IIC�ӿ�ͨѶ");


  /* ��ֱ�� */
//  RA8875_SetFrontColor(CL_BLUE);
  
//  
//  RA8875_SetFont( RA_FONT_32,  0,  0);
//  RA8875_DispStr(10,200,"���ߣ�");
//  
//  RA8875_DrawLine(50,250,750,250,CL_RED);
//  
//  RA8875_DrawLine(50,300,750,300,CL_RED);
//  
//  RA8875_DrawLine(400,250,200,400,CL_GREEN);
//  
//  RA8875_DrawLine(600,250,250,400,CL_GREEN);
//  
//  Delay(0xFFFFFF);
//  
//  RA8875_FillRect(0,200,LCD_HEIGHT-200,LCD_WIDTH,CL_BLACK);
//  

//  
//  /*������*/
//  RA8875_SetFrontColor(CL_BLUE);
//  RA8875_DispStr(10,200,"�����Σ�");
//  
//  RA8875_DrawRect(200,250,200,100,CL_RED);
//  RA8875_DrawRect(350,250,200,50,CL_GREEN);
//  RA8875_DrawRect(200,350,50,200,CL_BLUE);
//  
//  Delay(0xFFFFFF);
//  
//  RA8875_FillRect(0,200,LCD_HEIGHT-200,LCD_WIDTH,CL_BLACK);

//  

//  /*������*/
//  RA8875_SetFrontColor(CL_BLUE);
//  RA8875_DispStr(10,200,"������:");
// 
//  RA8875_FillRect(200,250,200,100,CL_RED);
//  RA8875_FillRect(350,250,200,50,CL_GREEN);
//  RA8875_FillRect(200,350,50,200,CL_BLUE);
//  
//  Delay(0xFFFFFF);
//  
//  RA8875_FillRect(0,200,LCD_HEIGHT-200,LCD_WIDTH,CL_BLACK);

//  /* ��Բ */
//  RA8875_SetFrontColor(CL_BLUE);
//  RA8875_DispStr(10,200,"��Բ:");
//  
//  RA8875_DrawCircle(200,350,50,CL_RED);
//  RA8875_DrawCircle(350,350,75,CL_GREEN);
//  
//  Delay(0xFFFFFF);
//  
//  RA8875_FillRect(0,200,LCD_HEIGHT-200,LCD_WIDTH,CL_BLACK);


//  /*���Բ*/
//  RA8875_SetFrontColor(CL_BLUE);
//  RA8875_DispStr(10,200,"���Բ��");
//  
//  RA8875_FillCircle(300,350,50,CL_RED);
//  RA8875_FillCircle(450,350,75,CL_GREEN);
//  
//  Delay(0xFFFFFF);
//  
//  RA8875_FillRect(0,200,LCD_HEIGHT-200,LCD_WIDTH,CL_BLACK);


}

/*********************************************END OF FILE**********************/

